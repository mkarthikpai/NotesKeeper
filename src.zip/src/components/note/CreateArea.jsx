import React, { useState } from "react";

const CreateArea = (props) => {
  const [note, setNote] = useState({ title: "", content: "" });

  const handleChange = (e) => {
    const { name, value } = e.target;

    setNote((prevState) => {
      return {
        ...prevState,
        [name]: value,
      };
    });
  };
  const submitNote = (e) => {
    e.preventDefault();
    props.onAdd(note);
    setNote({ title: "", content: "" });
  };

  return (
    <div>
      <form className="create-form">
        <input
          name="title"
          value={note.title}
          placeholder="Title"
          onChange={handleChange}
        />
        <textarea
          name="content"
          value={note.content}
          onChange={handleChange}
          placeholder="Take a note..."
          rows={3}
        />
        <button onClick={submitNote}>Add</button>
      </form>
    </div>
  );
};

export default CreateArea;
