import React from "react";

const Header = () => {
  return (
    <div>
      <header>
        <h1>Keeper App</h1>
      </header>
    </div>
  );
};

export default Header;
